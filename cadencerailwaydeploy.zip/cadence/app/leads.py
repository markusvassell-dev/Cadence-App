"""Lead-capture domain helpers (Phase 4): validation kept pure so it's testable
without FastAPI or a database."""

import re

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class LeadValidationError(ValueError):
    pass


def validate_lead(name: str | None, email: str | None) -> tuple[str, str]:
    """Validate a lead submission. Returns the cleaned (name, email) or raises
    LeadValidationError. Spec: name non-empty, email matches a basic regex."""
    name = (name or "").strip()
    email = (email or "").strip()
    if not name:
        raise LeadValidationError("name is required")
    if not _EMAIL_RE.match(email):
        raise LeadValidationError("a valid email is required")
    return name, email
