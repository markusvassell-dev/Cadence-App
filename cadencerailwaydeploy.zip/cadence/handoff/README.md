# Handoff: Marketing Automation App ("Cadence")

A bi-weekly content engine that researches a fresh market pain point, generates
guaranteed-unique SEO content for 4 platforms, captures leads into ActiveCampaign,
and drafts a 3-email nurture sequence — all triggered automatically by Karbon.

This package is a developer handoff for building the **real service** (target: Railway).

---

## ⚠️ Read this first — what's in this bundle

This bundle contains **two kinds of material**, and they serve different roles:

1. **`Automation Console.dc.html`** — a **design reference** (an interactive HTML
   prototype). It shows the intended *look and behavior* of the admin dashboard.
   It is **NOT production code to copy**. It runs on mock data and has no backend.
   Recreate this UI in whatever frontend framework you choose (see below), using
   its layout, colors, and flows as the spec.

2. **The build spec below + `SCHEMA.sql` + `PROMPTS.md`** — the **real engineering
   work**: the webhook service, database, research/content/email generation, the
   uniqueness engine, and the integrations. This is the bulk of the actual app and
   is what you'll spend most of your time on.

**Fidelity of the prototype: High-fidelity.** Colors, type, spacing, and
interactions are final. Recreate the UI pixel-close, but use your chosen
framework's idioms (don't port the `.dc.html` runtime — it's a prototyping tool).

---

## Recommended stack (greenfield — no existing codebase)

- **Backend:** Python + **FastAPI** (async, great for API orchestration) OR Node + Express. Spec below is framework-agnostic.
- **DB:** **Postgres** (Railway one-click). Use `pgvector` extension for the uniqueness engine (item 10).
- **Frontend:** **React + Vite** (or Next.js if you want SSR). The prototype maps cleanly to React components.
- **Hosting:** Railway. One service for the API, one Postgres plugin. Frontend can be a static build served by the API or a separate Railway static service.
- **LLM:** Anthropic Claude API (`claude-sonnet` class for content; cheaper model fine for extraction).
- **Search:** SerpAPI or Google Custom Search or a news API (NewsAPI/GDELT).
- **Email/CRM:** ActiveCampaign API v3.

---

## Build phases (do in order — each ends in a testable state)

### Phase 1 — Skeleton (½ day)
- FastAPI app, single `POST /hooks/run` endpoint. On hit: log timestamp, generate a
  `run` row (status `running`), call the orchestrator, return `{run_id, status}`.
- **Orchestrator** = one function chaining: `research() → generate() → distribute()`.
  Stub each with hard-coded returns + `print()` distribution. Prove the pipeline runs
  end to end before adding intelligence.
- Distribution stubs: `post_to_blog/linkedin/facebook/instagram(text)` → just log,
  prefixed with platform name. Keep these swappable behind a `Distributor` interface.

### Phase 2 — Real research + uniqueness guard (1–2 days)
- `research(market: str) -> {pain_point, source_insight}`: query search/news API for
  recent articles on the market, pass top results to Claude with the **Research
  Extraction prompt** (`PROMPTS.md`). Return structured JSON.
- **Uniqueness guard (pain points):** before returning, compare against all prior
  `pain_points.text` using string similarity (token-set ratio / Levenshtein).
  If similarity > 0.70 to any existing, discard and re-query (cap retries, e.g. 5).
  Persist accepted pain point to DB with timestamp + source.

### Phase 3 — Real content + hard uniqueness (3–5 days; the core)
- `generate(pain_point_obj) -> {blog, linkedin, facebook, instagram}` using the
  **Content Generation prompts** (`PROMPTS.md`). Blog ≥1000 words with meta title,
  meta description, H2 headers, internal-link *suggestions*, and a lead-magnet CTA.
  Each social post in the right tone/length, each ending in the lead-magnet CTA.
- **Absolute uniqueness enforcement (THE hard part):** maintain `content_registry`.
  For each new piece:
  1. Compute SHA-256 of normalized text → exact-duplicate check.
  2. Compute embedding (or TF-IDF vector) → cosine-similarity check vs. all prior
     pieces **of the same platform**. If cosine ≥ 0.30 (tune!), regenerate.
  3. Only on passing both, insert into registry. Registry rows are **immutable** —
     once locked, a piece can never be reused or regenerated away.
  Use `pgvector` + an ANN index so this stays fast as the registry grows.
- **Lead-magnet landing page:** generate an HTML page (or JSON the frontend renders)
  with a pain-point headline, Name + Email form, submit button. URL pattern
  `/lead-magnet/<unique-slug>`.

### Phase 4 — Form capture + ActiveCampaign (2–3 days)
- `POST /leads` endpoint: validate name (non-empty) + email (regex), then call
  ActiveCampaign API to create/update a contact with custom fields
  `lead_source` (= run id) and `pain_point`. Save `lead` row with the content id
  that produced it.
- After a successful contact push, draft a **3-email sequence** via the **Email
  Sequence prompt**: (1) deliver lead magnet, (2) educational, (3) soft pitch/case
  study. Save to `campaigns` as `draft`.

### Phase 5 — Production hardening + Karbon (2–4 days)
- **Karbon binding:** deploy so the webhook has a public URL. In Karbon, create a
  recurring work item (every 2 weeks) with an automation/webhook action pointed at
  `POST https://<your-app>.railway.app/hooks/run`. (Document the exact steps in code
  comments / a `DEPLOY.md`.)
- **Retries:** wrap every external call (search, Claude, ActiveCampaign) in
  retry-with-exponential-backoff. On exhausting retries, mark run `failed`, log, and
  alert an admin (email or log alert).
- **Pre-publish audit + dry run:** before any distribution, re-scan the full registry
  once more. Support a `dry_run=true` flag that runs research+generation and reports
  what *would* post without posting.
- **Real distribution (optional, when creds exist):** implement WordPress (REST),
  LinkedIn, Facebook, Instagram. Keep console stubs as the fallback behind the
  `Distributor` interface. **Non-code blocker:** Meta (FB/IG) and LinkedIn require
  business accounts, OAuth apps, and platform app-review — budget weeks of approval
  waiting, independent of coding.

---

## Screens (recreate from `Automation Console.dc.html`)

The prototype is a left-sidebar admin console. Sidebar nav: **Overview, Content
review, Lead magnet, Leads, Campaigns, Settings.** Top bar shows the active market,
a status chip, and a **Trigger run** button (becomes **Dry run** when dry-run mode
is on). A run animation overlay shows the 5 pipeline steps; a toast confirms results.

1. **Overview** — 4 metric cards (runs completed, leads captured, content pieces,
   uniqueness rate), a "latest run ready for review" banner, and a **Run history**
   table (run id, date, pain point, status badge, leads, novelty bar). Rows click
   into Run detail. Statuses: `running / review / published / failed`.
2. **Run detail** — the extracted pain point, the source insight (accent left-border
   callout), novelty score / registry collisions / leads cards, and buttons into
   content review + lead magnet.
3. **Content review** — uniqueness pass banner; a **blog card** (meta title, meta
   description, H2 headers, body excerpt, lead-magnet CTA, content hash + TF-IDF
   similarity, Approve/Regenerate); three **social cards** (LinkedIn, Facebook,
   Instagram) each with text, similarity score, Approve/Redo. Approving locks a piece
   into the registry. "Approve all & queue" footer.
4. **Lead magnet** — full landing-page preview (headline, benefit checklist, Name +
   Email form). Submitting validates, shows a success state, and creates a lead.
5. **Leads** — table of captured contacts (name, email, pain point, source run, sync
   status) synced to ActiveCampaign list. New form submissions append here live.
6. **Campaigns** — the 3-email nurture sequence as draft cards (subject, goal, timing,
   preview, body), with Approve sequence / Edit in ActiveCampaign.
7. **Settings** — Schedule & webhook URL (copyable), Research & generation (search API
   key, LLM provider, uniqueness threshold), ActiveCampaign (API URL, list id),
   Distribution channels (connected / reconnect / stub states).

**Tweakable props on the root** (mirror as app settings/theme): `theme` (light|dark),
`accent` (violet|teal|blue), `dryRun` (boolean).

---

## Design tokens (from the prototype)

**Light theme**
- bg `#F3F3F5`, panel `#FFFFFF`, panel-2 `#FAFAFA`
- border `#E8E8EB`, border-strong `#DADADE`
- ink `#191920`, ink-2 `#55555E`, muted `#8B8B95`
- accent (violet) `#5B47F5` · (teal) `#0E9E84` · (blue) `#2D6BF0`
- success `#13935A`, warn `#B07418`, danger `#D24039` (each with a ~12% soft tint)

**Dark theme**
- bg `#0B0B0E`, panel `#151519`, panel-2 `#1A1A20`
- border `#272730`, border-strong `#34343E`
- ink `#F0F0F3`, ink-2 `#B4B4BE`, muted `#73737E`

**Type:** `Hanken Grotesk` (UI, weights 400–800), `JetBrains Mono` (ids, hashes,
emails, code-ish values). **Radius:** cards 13px, controls 9px, pills 999px.
**Shadow (cards):** `0 1px 2px rgba(20,20,30,.05), 0 1px 3px rgba(20,20,30,.05)`.

---

## Files in this bundle
- `Automation Console.dc.html` — the interactive UI prototype (design reference).
- `SCHEMA.sql` — Postgres schema for runs, pain points, content registry, leads, campaigns.
- `PROMPTS.md` — ready-to-use LLM prompts for research, content, and email generation.
- `README.md` — this document (self-sufficient build spec).
